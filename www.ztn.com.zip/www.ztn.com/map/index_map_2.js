(function () {
  var myChart = echarts.init(document.getElementById('index_map_2'))

  var geoCoordMap = {
    "南京市": [118.806446, 32.065142],
  }

  const citys = Object.keys(geoCoordMap).map(city => {
    return {
      name: city
    }
  })
  console.log(citys)
  var convertData = function (data) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
      var geoCoord = geoCoordMap[data[i].name];
      if (geoCoord) {
        res.push(geoCoord.concat(data[i].value).concat(data[i].name));
      }
    }
    return res;
  }

  option = {
    backgroundColor: '#404a59',
    title: {
      left: 'center',
      textStyle: {
        color: '#fff'
      }
    },
    geo: {
      map: '江苏',
      label: {
        normal: {
          show: true,
          areaColor: '#ffffff',
          borderColor: '#111',
          textStyle: { color: "#008A94" }
        },
        emphasis: {
          show: false,
          textStyle: { color: "#fff" }
        }
      },
      itemStyle: {
        normal: {
          show: false,
          areaColor: '#ffffff',
          borderColor: '#009fe8'
        },
        emphasis: {
          show: false,
          areaColor: '#008A94'
        }
      }
    },
    series: [
      {
        name: '地点',
        type: 'effectScatter',
        coordinateSystem: 'geo',
        color: '#EE4B13',
        symbolSize: 15,
        data: convertData(citys),
        symbolSize: 12,
        itemStyle: {
          normal: {
            color: '#EE4B13',
            borderWidth: .5,//区域边框宽度
            borderColor: '#009fe8',//区域边框颜色
            areaColor: "#ffefd5",//区域颜色
          },
          emphasis: {
            show: true,
            borderWidth: .5,
            borderColor: '#4b0082',
            areaColor: "#f47920",
          }
        },
      }
    ],
    tooltip: {
      "trigger": "item",
      "confine": true,
      "formatter": (p) => {
        let dataCon = p.data,
          txtCon = `${dataCon[3]}`
        return txtCon

      }
    },
  };
  myChart.setOption(option);
})()
